function imshowz(im)

imshow(abs(im),[])