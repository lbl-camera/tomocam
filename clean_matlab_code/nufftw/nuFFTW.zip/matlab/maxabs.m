function ma = maxabs(data)

ma = max(abs(data(:)));